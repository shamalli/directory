<?php

global $w2dc_buttons_widget_params;
$w2dc_buttons_widget_params = array(
		array(
				'type' => 'directories',
				'param_name' => 'directories',
				'heading' => esc_html__("Set specific directory for submit button", "W2DC"),
				'description' => esc_html__("Select some items to dispay submit buttons for each directory", "W2DC"),
		),
		array(
				'type' => 'dropdown',
				'param_name' => 'hide_button_text',
				'value' => array(esc_html__('No', 'W2DC') => '0', esc_html__('Yes', 'W2DC') => '1'),
				'heading' => esc_html__('Hide button names, display only popups', 'W2DC'),
		),
		array(
				'type' => 'checkbox',
				'param_name' => 'buttons',
				'value' => array(
						esc_html__('Submit button', 'W2DC') => 'submit',
						esc_html__('My bookmarks page link', 'W2DC') => 'favourites',
						esc_html__('Claim button (only on single listing page)', 'W2DC') => 'claim',
						esc_html__('Edit listing button (only on single listing page)', 'W2DC') => 'edit',
						esc_html__('Print listing button (only on single listing page)', 'W2DC') => 'print',
						esc_html__('Bookmark listing button (only on single listing page)', 'W2DC') => 'bookmark',
						esc_html__('Save PDF listing button (only on single listing page)', 'W2DC') => 'pdf',
						esc_html__('Logout button', 'W2DC') => 'logout',
				),
				'std' => array('submit', 'favourites', 'claim', 'edit', 'print', 'bookmark', 'pdf', 'logout'),
				'heading' => esc_html__('Select buttons to display', 'W2DC'),
				'description' => esc_html__('Most of buttons can be displayed only on single listings pages', 'W2DC'),
		),
		array(
				'type' => 'checkbox',
				'param_name' => 'visibility',
				'heading' => esc_html__("Show only on directory pages", "W2DC"),
				'value' => 0,
				'description' => esc_html__("Otherwise it will load plugin's files on all pages", "W2DC"),
		),
);

class w2dc_buttons_widget extends w2dc_widget {

	public function __construct() {
		global $w2dc_instance, $w2dc_buttons_widget_params;

		parent::__construct(
				'w2dc_buttons_widget',
				esc_html__('Directory widget - Buttons', 'W2DC')
		);

		$this->convertParams($w2dc_buttons_widget_params);
	}
	
	public function render_widget($instance, $args) {
		global $w2dc_instance;
		
		// when visibility enabled - show only on directory pages
		if (empty($instance['visibility']) || !empty($w2dc_instance->frontend_controllers)) {
			$title = apply_filters('widget_title', $instance['title']);
	
			echo $args['before_widget'];
			if (!empty($title)) {
				echo $args['before_title'] . $title . $args['after_title'];
			}
			echo '<div class="w2dc-content w2dc-widget w2dc-buttons-widget">';
			$controller = new w2dc_buttons_controller();
			$controller->init($instance);
			echo $controller->display();
			echo '</div>';
			echo $args['after_widget'];
		}
	}
}
?>