<div class="w2dc-content">
	<?php w2dc_renderMessages(); ?>

	<h3><?php esc_html_e('Register For This Site.', 'w2dc') ?></h3>

	<div class="w2dc-submit-section-adv">
		<?php w2dc_registration_form(); ?>
	</div>
</div>