<div class="w2rr-content">
	<?php w2rr_renderMessages(); ?>

	<h3><?php esc_html_e('Please enter your username or email address. You will receive a link to create a new password via email.', 'w2rr') ?></h3>

	<div class="w2rr-submit-section-adv">
		<?php w2rr_lostpassword_form(); ?>
	</div>
</div>