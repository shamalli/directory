<div class="w2rr-content">
	<?php w2rr_renderMessages(); ?>

	<h3><?php esc_html_e('Register For This Site.', 'W2RR') ?></h3>

	<div class="w2rr-submit-section-adv">
		<?php w2rr_registration_form(); ?>
	</div>
</div>