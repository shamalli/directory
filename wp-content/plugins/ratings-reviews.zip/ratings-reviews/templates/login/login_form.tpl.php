<div class="w2rr-content">
	<?php w2rr_renderMessages(); ?>

	<div class="w2rr-submit-section-adv">
		<?php w2rr_login_form(); ?>
		<?php //echo "xxx"; ?>
	</div>
</div>