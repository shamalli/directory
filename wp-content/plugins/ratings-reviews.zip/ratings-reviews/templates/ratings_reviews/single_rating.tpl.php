<div class="w2rr-rating">
	<div class="w2rr-rating-stars">
		<label class="w2rr-rating-icon w2rr-fa <?php echo $rating->render_star(5); ?>"></label>
		<label class="w2rr-rating-icon w2rr-fa <?php echo $rating->render_star(4); ?>"></label>
		<label class="w2rr-rating-icon w2rr-fa <?php echo $rating->render_star(3); ?>"></label>
		<label class="w2rr-rating-icon w2rr-fa <?php echo $rating->render_star(2); ?>"></label>
		<label class="w2rr-rating-icon w2rr-fa <?php echo $rating->render_star(1); ?>"></label>
	</div>
</div>