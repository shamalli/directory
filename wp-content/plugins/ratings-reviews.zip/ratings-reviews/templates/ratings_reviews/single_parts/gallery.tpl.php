<div class="w2rr-content">
	<div class="w2rr-review-logo-wrap w2rr-single-review-logo-wrap" id="images">
		<?php do_action('w2rr_review_pre_logo_wrap_html', $review); ?>
		
		<?php $review->renderImagesGallery(); ?>
	</div>
</div>