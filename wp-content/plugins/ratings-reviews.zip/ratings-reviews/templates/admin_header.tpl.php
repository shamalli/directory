<div class="wrap">
	<?php w2rr_renderMessages(); ?>
	