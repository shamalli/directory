<?php

/* function w2rr_wc_multi_ratings($ratings_criterias) {
	$target_post = w2rr_getTargetPost();
	
	$ratings_criterias = array(
			'1',
			'2',
			'3',
	);
	
	$ratings_criterias = array_filter($ratings_criterias);
	
	return $ratings_criterias;
}
add_filter('w2rr_multi_ratings', 'w2rr_wc_multi_ratings'); */

?>