<?php

/**
 * Implement this interface to state that the field control is Multi Selectable
 */
interface W2RR_VP_MultiSelectable{}

/**
 * EOF
 */