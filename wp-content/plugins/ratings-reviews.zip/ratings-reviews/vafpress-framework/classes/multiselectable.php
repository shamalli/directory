<?php

/**
 * Implement this interface to state that the field control is Multi Selectable
 */
interface VP_W2RR_MultiSelectable{}

/**
 * EOF
 */