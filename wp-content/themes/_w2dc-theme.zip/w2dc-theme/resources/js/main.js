
(function($) {
	"use strict";
	
	$(function() {
		$("#mobile-trigger").click(function() {
			$("#mobile").slideToggle(500);
		});
		
		if ($(".site-header.header-fixed").length) {
			var headerHeight = $('.site-header.header-fixed').outerHeight();
			$('.header-fixed-clone')
			.show()
			.css('height', headerHeight);

			$('.site-header.header-fixed').addClass('fixed');
		}
		
		var removePreloader = function() {
			$('.preloader').css('opacity', 0);
	    	setTimeout(function() {
	    		$('.preloader').hide();
	    	}, 800);
		}
		removePreloader();
	});
})(jQuery);
