<?php

function wdt_customize_register($wp_customize) {
	
	$wp_customize->add_panel('theme_settings',
			array(
					'title' => __('Theme Settings', 'WDT'),
					'title',
					'priority' => 60,
			)
	);
	
	// Fonts Section
	$wp_customize->add_section('fonts',
			array(
					'title' => __('Fonts', 'WDT'),
					'panel' => 'theme_settings',
		/* 'default' => 4,
		  'section' => 'title_tagline',
		  'label' => __( 'Range' ),
		  'description' => __( 'This is the range control description.' ),
		) */
			)
	);
	
	$wp_customize->add_setting('body_font',
			array(
					'default' => wdt_get_option('body_font'),
					'sanitize_callback' => 'wdt_sanitize_font',
			)
	);
	$wp_customize->add_control(
			new Font_Dropdown_Custom_Control($wp_customize, 'body_font', array(
					'label' => __('Body Font', 'WDT'),
					'section' => 'fonts',
        ))
	);
	
	$wp_customize->add_setting('body_font_size',
			array(
					'default' => wdt_get_option('body_font_size'),
			)
	);
	$wp_customize->add_control('body_font_size',
			array(
					'label' => __('Body Font Size', 'WDT'),
					'description'   => __('in pixels', 'WDT'),
					'type' => 'number',
					'section' => 'fonts',
					'input_attrs' => array('min' => 10, 'max' => 60),
			)
	);

	$wp_customize->add_setting('nav_menu_font',
			array(
					'default' => wdt_get_option('nav_menu_font'),
					'sanitize_callback' => 'wdt_sanitize_font',
			)
	);
	$wp_customize->add_control(
			new Font_Dropdown_Custom_Control($wp_customize, 'nav_menu_font', array(
					'label' => __('Navigation Menu Font', 'WDT'),
					'section' => 'fonts',
        ))
	);
	
	$wp_customize->add_setting('nav_menu_font_size',
			array(
					'default' => wdt_get_option('nav_menu_font_size'),
			)
	);
	$wp_customize->add_control('nav_menu_font_size',
			array(
					'label' => __('Navigation Menu Font Size', 'WDT'),
					'description' => __('in pixels', 'WDT'),
					'type' => 'number',
					'section' => 'fonts',
					'input_attrs' => array('min' => 10, 'max' => 60),
			)
	);

	$wp_customize->add_setting('headings_font',
			array(
					'default' => wdt_get_option('headings_font'),
					'sanitize_callback' => 'wdt_sanitize_font',
			)
	);
	$wp_customize->add_control(
			new Font_Dropdown_Custom_Control($wp_customize, 'headings_font', array(
					'label' => __('Headings Font', 'WDT'),
					'section' => 'fonts',
        	))
	);
	
	// Header Section
	$wp_customize->add_section('header',
			array(
					'title' => __('Header', 'WDT'),
					'panel' => 'theme_settings',
			)
	);
	
	$wp_customize->add_setting('header_fixed_scroll_enable',
			array(
					'default' => wdt_get_option('header_fixed_scroll_enable'),
			)
	);
	$wp_customize->add_control('header_fixed_scroll_enable',
			array(
					'label' => esc_html__('Enable Fixed Scroll Header', 'WDT'),
					'section' => 'header',
					'type' => 'checkbox',
			)
	);

	$wp_customize->add_setting('header_background',
			array(
					'default' => wdt_get_option('header_background'),
			)
	);
	$wp_customize->add_control(
			new WP_Customize_Color_Control($wp_customize, 'header_background', array(
					'label'   => 'Header Background Color',
					'section' => 'header',
					//'settings' => 'color_setting',
			))
	);
	$wp_customize->add_setting('header_text_color',
			array(
					'default' => wdt_get_option('header_text_color'),
			)
	);
	$wp_customize->add_control(
			new WP_Customize_Color_Control($wp_customize, 'header_text_color', array(
					'label'   => 'Header Text Color',
					'section' => 'header',
					//'settings' => 'color_setting',
			))
	);

	/* $wp_customize->add_setting('header_contact_number',
			array(
					'default' => '',
			)
	);
	$wp_customize->add_control('header_contact_number',
			array(
					'label' => __('Contact Number', 'WDT'),
					'section' => 'header',
					'type' => 'text',
			)
	);

	$wp_customize->add_setting('header_contact_email',
			array(
					'default' => '',
			)
	);
	$wp_customize->add_control('header_contact_email',
			array(
					'label' => __('Contact Email', 'WDT'),
					'section' => 'header',
					'type' => 'text',
			)
	);

	$wp_customize->add_setting('header_contact_address',
			array(
					'default' => '',
			)
	);
	$wp_customize->add_control('header_contact_address',
			array(
					'label' => __('Contact Address', 'WDT'),
					'section' => 'header',
					'type' => 'text',
			)
	);
	
	$wp_customize->add_setting('header_search',
			array(
					'default' => false,
			)
	);
	$wp_customize->add_control('header_search',
			array(
					'label' => __('Enable Search Form', 'WDT'),
					'section' => 'header',
					'type' => 'checkbox',
			)
	); */
	
	$wp_customize->add_setting('nav_menu_paddings',
			array(
					'default' => wdt_get_option('nav_menu_paddings'),
			)
	);
	$wp_customize->add_control('nav_menu_paddings',
			array(
					'label' => __('Horizontal Paddings in Navigation Menu items', 'WDT'),
					'description' => __('in pixels', 'WDT'),
					'type' => 'number',
					'section' => 'header',
					'input_attrs' => array('min' => 0, 'max' => 200),
			)
	);
	
	$wp_customize->add_setting('show_title',
			array(
					'default' => wdt_get_option('show_title'),
			)
	);
	$wp_customize->add_control('show_title',
			array(
					'label' => __('Show Site Title', 'WDT'),
					'section' => 'header',
					'type' => 'checkbox',
			)
	);

	$wp_customize->add_setting('show_tagline',
			array(
					'default' => wdt_get_option('show_tagline'),
			)
	);
	$wp_customize->add_control('show_tagline',
			array(
					'label' => __('Show TagLine', 'WDT'),
					'section' => 'header',
					'type' => 'checkbox',
			)
	);
	
	// Links Section
	$wp_customize->add_section('links',
			array(
					'title' => __('Links', 'WDT'),
					'panel' => 'theme_settings',
			)
	);

	// Load custom controls.
	/* require get_template_directory() . '/inc/customizer/control.php';

	// Load customize helpers.
	require get_template_directory() . '/inc/helper/options.php';

	// Load customize sanitize.
	require get_template_directory() . '/inc/customizer/sanitize.php';

	// Load customize callback.
	require get_template_directory() . '/inc/customizer/callback.php';

	$wp_customize->get_setting( 'blogname' )->transport        = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	// Load customize option.
	require get_template_directory() . '/inc/customizer/option.php';

	// Load slider customize option.
	require get_template_directory() . '/inc/customizer/slider.php';

	// Register custom section types.
	$wp_customize->register_section_type( 'Nature_Bliss_Customize_Section_Upsell' );

	// Register sections.
	$wp_customize->add_section(
		new Nature_Bliss_Customize_Section_Upsell(
			$wp_customize,
			'theme_upsell',
			array(
				'title'    => esc_html__( 'Nature Bliss Pro', 'nature-bliss' ),
				'pro_text' => esc_html__( 'Buy Pro', 'nature-bliss' ),
				'pro_url'  => 'http://themepalace.com/downloads/nature-bliss-pro/',
				'priority'  => 1,
			)
		)
	); */
}
add_action('customize_register', 'wdt_customize_register');

/**
 * Customizer partials.
 *
 * @since 1.0.0
 */
function nature_bliss_customizer_partials( WP_Customize_Manager $wp_customize ) {

    // Abort if selective refresh is not available.
    if ( ! isset( $wp_customize->selective_refresh ) ) {

		$wp_customize->get_setting( 'blogname' )->transport                      = 'refresh';
		$wp_customize->get_setting( 'blogdescription' )->transport               = 'refresh';
		$wp_customize->get_setting( 'theme_options[copyright_text]' )->transport = 'refresh';
		return;

    }

    // Load customizer partials callback.
   // require get_template_directory() . '/inc/customizer/partials.php';

    // Partial blogname.
    $wp_customize->selective_refresh->add_partial( 'blogname', array(
		'selector'            => '.site-title a',
		'container_inclusive' => false,
		'render_callback'     => 'nature_bliss_customize_partial_blogname',
    ) );

    // Partial blogdescription.
    $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
		'selector'            => '.site-description',
		'container_inclusive' => false,
		'render_callback'     => 'nature_bliss_customize_partial_blogdescription',
    ) );

    // Partial copyright_text.
    $wp_customize->selective_refresh->add_partial( 'copyright_text', array(
		'selector'            => '#colophon .copyright',
		'container_inclusive' => false,
		'settings'            => array( 'theme_options[copyright_text]' ),
		'render_callback'     => 'nature_bliss_render_partial_copyright_text',
    ) );

}

add_action( 'customize_register', 'nature_bliss_customizer_partials', 99 );

/**
 * Customizer control scripts and styles.
 *
 * @since 1.0.0
 */
function nature_bliss_customizer_control_scripts() {

	$min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	wp_enqueue_script( 'nature-bliss-customize-controls', get_template_directory_uri() . '/js/customize-controls' . $min . '.js', array( 'customize-controls' ) );

	wp_enqueue_style( 'nature-bliss-customize-controls', get_template_directory_uri() . '/css/customize-controls' . $min . '.css' );

}

add_action( 'customize_controls_enqueue_scripts', 'nature_bliss_customizer_control_scripts', 0 );
