<?php if (wdt_get_option('body_font')): ?>
body {
	font-family: '<?php echo wdt_get_option('body_font'); ?>', sans-serif;
}
<?php endif; ?>
<?php if (wdt_get_option('body_font_size')): ?>
body {
	font-size: <?php echo wdt_get_option('body_font_size'); ?>px;
}
<?php endif; ?>
<?php if (wdt_get_option('nav_menu_font')): ?>
.main-navigation ul li a {
	font-family: '<?php echo wdt_get_option('nav_menu_font'); ?>', sans-serif;
}
<?php endif; ?>
<?php if (wdt_get_option('nav_menu_font_size')): ?>
.main-navigation ul li a {
	font-size: <?php echo wdt_get_option('nav_menu_font_size'); ?>px;
}
<?php endif; ?>
<?php if (wdt_get_option('nav_menu_paddings')): ?>
.main-navigation ul li a {
	padding-left: <?php echo wdt_get_option('nav_menu_paddings'); ?>px;
	padding-right: <?php echo wdt_get_option('nav_menu_paddings'); ?>px;
}
<?php endif; ?>
<?php if (wdt_get_option('headings_font')): ?>
h1, .w2dc-content h1,
h2, .w2dc-content h2,
h3, .w2dc-content h3,
h4, .w2dc-content h4,
h5, .w2dc-content h5,
h6, .w2dc-content h6 {
	font-family: '<?php echo wdt_get_option('headings_font'); ?>', sans-serif;
}
<?php endif; ?>
<?php if (wdt_get_option('header_background')): ?>
.site-header,
.main-navigation ul ul {
	background-color: <?php echo wdt_get_option('header_background'); ?>;
}
<?php endif; ?>
<?php if (wdt_get_option('header_text_color')): ?>
.site-header,
.main-navigation {
	color: <?php echo wdt_get_option('header_text_color'); ?>;
}
<?php endif; ?>