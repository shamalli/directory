﻿=== Web Directory Theme ===
Contributors: Mihail Chepovskiy
Donate link: http://www.salephpscripts.com/
Tags: business directory
Requires at least: 3.6.2
Tested up to: 4.9
Stable tag: tags/1.0.0
License: Free



Look at our [demo](http://www.salephpscripts.com/wordpress_directory/demo/)

== Changelog ==